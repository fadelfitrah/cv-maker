const jwt = require("jsonwebtoken");
const { pool } = require("../config/db");

exports.authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({
        success: false,
        message: "Silakan login untuk melanjutkan.",
      });
    }

    const token = authHeader.split(" ")[1];

    if (!process.env.JWT_SECRET) {
      throw new Error("JWT_SECRET belum dikonfigurasi.");
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const [rows] = await pool.query(
      `SELECT id, name, email, role, plan_status,
              pro_started_at, pro_expires_at
       FROM users
       WHERE id = ?
       LIMIT 1`,
      [decoded.id],
    );

    if (rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: "Akun tidak ditemukan. Silakan login kembali.",
      });
    }

    req.user = rows[0];
    next();
  } catch (error) {
    if (
      error.name === "JsonWebTokenError" ||
      error.name === "TokenExpiredError"
    ) {
      return res.status(401).json({
        success: false,
        message: "Sesi login tidak valid atau sudah berakhir.",
      });
    }

    console.error("Authentication Error:", error);

    return res.status(500).json({
      success: false,
      message: "Gagal memverifikasi sesi pengguna.",
    });
  }
};

exports.requirePro = (req, res, next) => {
  const user = req.user;

  // Admin tidak perlu berlangganan untuk mengakses fitur internal.
  if (user.role === "admin") {
    return next();
  }

  const expiresAt = user.pro_expires_at
    ? new Date(user.pro_expires_at).getTime()
    : NaN;

  const isProActive =
    user.plan_status === "pro" &&
    Number.isFinite(expiresAt) &&
    expiresAt > Date.now();

  if (!isProActive) {
    return res.status(403).json({
      success: false,
      code: "PRO_REQUIRED",
      message:
        "Fitur ini memerlukan akun Pro yang masih aktif. Silakan upgrade paket Anda.",
      data: {
        plan_status: user.plan_status,
        pro_expires_at: user.pro_expires_at,
      },
    });
  }

  next();
};
